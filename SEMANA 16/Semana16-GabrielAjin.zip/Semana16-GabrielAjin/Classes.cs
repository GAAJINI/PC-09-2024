﻿using Classes;

var account = new BankAccount("<name>", 1000);
Console.WriteLine($"Account {account.Number} was created for {account.Owner} with {account.Balance} balance.");

account.MakeWithdrawal(500, DateTime.Now, "Rent payment");
Console.WriteLine(account.Balance);
account.MakeDeposit(100, DateTime.Now, "friend paid me back");
Console.WriteLine(account.Balance);

Console.WriteLine(account.GetAccountHistory());

// Test that the initial balances must be positive:
try
{
    var invalidAccount = new BankAccount("invalid", -70);
}
catch (ArgumentOutOfRangeException e)
{
    Console.WriteLine("Se detectó una excepción al crear una cuenta con saldo negativo");
    Console.WriteLine(e.ToString());
}

// Test for a negative balance
try
{
    account.MakeWithdrawal(800, DateTime.Now, "Intento de sobreescritura");
}
catch (InvalidOperationException e)
{
    Console.WriteLine("Excpecion capturada cuando se trato de sobreescribir");
    Console.WriteLine(e.ToString());
}

try
{
    
    var invalidAccount = new BankAccount(null, 100);
}
catch (ArgumentNullException e)
{
    Console.WriteLine("Uno de los argumentos proporcionados es nulo");
    Console.WriteLine(e.ToString());
}
try
{
        var invalidAccount = new BankAccount("", 100);
}
catch (ArgumentException e)
{
    Console.WriteLine("Uno de los argumentos proporcionados no es válido");
    Console.WriteLine(e.ToString());
}
