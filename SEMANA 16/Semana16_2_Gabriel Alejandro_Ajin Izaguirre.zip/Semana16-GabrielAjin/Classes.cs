﻿using Classes;


var account = new BankAccount("Gabriel", 1000);
Console.WriteLine($"Cuenta {account.Number} de tipo {account.TipodeCuenta} fue creada por {account.Owner} con {account.Balance} de balance.");

account.MakeWithdrawal(500, DateTime.Now, "Rent payment");
Console.WriteLine(account.Balance);
account.MakeDeposit(100, DateTime.Now, "friend paid me back");
Console.WriteLine(account.Balance);

Console.WriteLine(account.GetAccountHistory());

