﻿using System;
using System.Collections.Generic;

namespace Classes;

public class BankAccount
{
    public string Number { get; }
    public string Owner { get; set; }
    public string TipodeCuenta { get; set; }

    #region BalanceComputation
    public decimal Balance
    {
        get
        {
            decimal balance = 0;
            foreach (var item in _allTransactions)
            {
                balance += item.Amount;
            }

            return balance;
        }
    }
    #endregion

    #region Constructor
    public BankAccount(string name, decimal initialBalance)
    {
        Console.WriteLine("Ingresa el Tipo de Cuenta");
        TipodeCuenta = Console.ReadLine();

        Console.WriteLine("Ingresa el Numero de la Cuenta");
        Number = Console.ReadLine();

        Console.WriteLine("Ingresa el Nombre del Propietario de la Cuenta");
        name = Console.ReadLine();
        Owner = name;
        MakeDeposit(initialBalance, DateTime.Now, "Initial balance");

        Menu();

    }
    public void MostrarDatos()
    {
        Console.WriteLine($"Numero de Cuenta: {Number}");
        Console.WriteLine($"Tipo de Cuenta: {TipodeCuenta}");
        Console.WriteLine($"Nombre del Propietario: {Owner}");
        Console.WriteLine($"Balance Inicial: {Balance}");
    }

    public void Menu()
    {
        bool mostrarMenu = true;
        while (mostrarMenu)
        {
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("MENU DE USUARIO");
            Console.WriteLine("1. MOSTRAR DATOS");
            Console.WriteLine("2. SALIR");
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("");
            Console.WriteLine("INGRESE LA OPCION QUE DESEA EFECTUAR");
            int numero;
            if (int.TryParse(Console.ReadLine(), out numero))
            {
                switch (numero)
                {
                    case 1:
                        Console.WriteLine("MOSTRAR DATOS");
                        MostrarDatos();
                        Console.ReadKey();
                        break;
                    case 2:
                        Console.WriteLine("SALIR");
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("La opción seleccionada no es válida.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Por favor, ingrese un número válido.");
            }
        }
    }


    #endregion

    #region TransactionDeclaration
    private List<Transaction> _allTransactions = new List<Transaction>();
    #endregion

    #region DepositAndWithdrawal
    public void MakeDeposit(decimal amount, DateTime date, string note)
    {
        if (amount <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(amount), "Amount of deposit must be positive");
        }
        var deposit = new Transaction(amount, date, note);
        _allTransactions.Add(deposit);
    }

    public void MakeWithdrawal(decimal amount, DateTime date, string note)
    {
        if (amount <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(amount), "Amount of withdrawal must be positive");
        }
        if (Balance - amount < 0)
        {
            throw new InvalidOperationException("Not sufficient funds for this withdrawal");
        }
        var withdrawal = new Transaction(-amount, date, note);
        _allTransactions.Add(withdrawal);
    }
    #endregion

    #region History
    public string GetAccountHistory()
    {
        var report = new System.Text.StringBuilder();

        decimal balance = 0;
        report.AppendLine("Date\t\tAmount\tBalance\tNote");
        foreach (var item in _allTransactions)
        {
            balance += item.Amount;
            report.AppendLine($"{item.Date.ToShortDateString()}\t{item.Amount}\t{balance}\t{item.Notes}");
        }

        return report.ToString();
    }
    #endregion
}