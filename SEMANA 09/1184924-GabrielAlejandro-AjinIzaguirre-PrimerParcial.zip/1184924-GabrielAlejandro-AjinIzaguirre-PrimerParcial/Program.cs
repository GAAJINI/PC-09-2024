﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Determinacion Edad");
int edadendias;
Console.WriteLine("Ingrese nombre");
string nombre = (Console.ReadLine());
Console.WriteLine("Ingrese la edad en años:");
int edad = int.Parse(Console.ReadLine());

string etapaedad = "";

switch (edad)
{
	case >= 0 and <= 5:
		etapaedad = "Primera Infancia";
		break;
	case >= 6 and <= 11:
		etapaedad = "Infancia";
		break ;
    case >= 12 and <= 18:
        etapaedad = "Adolescencia";
        break;
    case >= 19 and <= 25:
        etapaedad = "Juventud";
        break;
    case >= 26 and <= 59:
        etapaedad = "Adultez";
        break;
    case >= 60:
        etapaedad = "Persona Mayor";
        break;

    default:
		etapaedad = "";
		break;
}

edadendias = edad * 365;

Console.WriteLine(etapaedad);
Console.WriteLine(nombre + " tu edad es " + edad + " años, con " + edadendias +" dias");

