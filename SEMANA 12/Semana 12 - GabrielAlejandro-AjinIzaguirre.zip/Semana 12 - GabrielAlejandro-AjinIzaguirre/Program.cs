﻿namespace Semana12_GabrielAjin_1184924  
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
        }

        static void menu()
        {
            Console.WriteLine("Ingrese un número");
            int numero1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese un número");
            int numero2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Semana 12");
            Console.WriteLine("1. Multiplicación");
            Console.WriteLine("2. Suma");
            Console.WriteLine("3. Resta ");

            int opcion= int.Parse(Console.ReadLine());

           switch (opcion)
            {
                case 1:
                    Console.WriteLine("El resultado es :" + Multiplicacion(numero1,numero2));
                    Console.ReadKey();

                    break;
                case 2:
                    Console.WriteLine("El resultado es :" + Suma(numero1, numero2));
                    Console.ReadKey();

                    break;
                case 3:       
                    Console.WriteLine("El resultado es :" + Resta(numero1, numero2));
                    Console.ReadKey();

                    break;
                default:
                    Console.WriteLine("La opción seleccionada no es válida.");
                    break;
            }
        }

        //envio de parámetros
        public static int Multiplicacion(int numero1, int numero2)
        {
            int resultado = 0;
            resultado = numero1 * numero2;
            return resultado;
        }
        public static int Suma(int numero1, int numero2)
        {
            int resultado = 0;
            resultado = numero1 + numero2;
            return resultado;
        }
        public static int Resta(int numero1, int numero2)
        {
            int resultado = 0;
            resultado = numero1 - numero2;
            return resultado;
        }

    }
}




