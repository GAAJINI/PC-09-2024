﻿using System;

namespace Arreglos
{
    class ArregloUnidimensional
    {
        private string[][] datos;

        public void Cargar()
        {
            datos = new string[4][];

            for (int i = 0; i < 4; i++)
            {
                datos[i] = new string[4];

                Console.WriteLine($"Ingrese el nombre de la persona {i + 1}:");
                datos[i][0] = Console.ReadLine();

                Console.WriteLine($"Ingrese el apellido de la persona {i + 1}:");
                datos[i][1] = Console.ReadLine();

                Console.WriteLine($"Ingrese la edad de la persona {i + 1}:");
                datos[i][2] = Console.ReadLine();
                
                Console.WriteLine($"Ingrese el telefono de la persona {i + 1}:");
                datos[i][3] = Console.ReadLine();
            }
        }

        public void Imprimir()
        {
            Console.WriteLine(" NOMBRES ----- APELLIDDOS ---- EDAD ---- TELEFONO");
            
            for (int i = 0; i < 4; i++)
            {
               
                Console.WriteLine($" {datos[i][0]} ----- {datos[i][1]} ----- {datos[i][2]} ----- {datos[i][3]}");
            }
        }

        static void Main()
        {
            ArregloUnidimensional arregloUnidimensional_ = new ArregloUnidimensional();
            arregloUnidimensional_.Cargar();
            arregloUnidimensional_.Imprimir();
        }
    }
}
