﻿using System;

namespace Tareasemana_10
{
    class Programsemana_10
    {
        static void Main(string[] args)
        {
            Console.Write("INGRESA UN NUMERO POSITIVO ");
            int numero= int.Parse(Console.ReadLine());
            
            int resultado = CalcularFactorial(numero);
            Console.WriteLine("EL FACTORIAL DEL NUMERO: "+numero);
            Console.WriteLine("ES:" +resultado);
        }

        public static int CalcularFactorial(int numero)
        {
            if (numero == 0)
            {
                return 1;
            }
            else
            {
                int factorial = 1;
                for (int i = 1; i <= numero; i++)
                {
                    factorial *= i;
                }
                return factorial;
            }
        }
    }
}