﻿using System;

public class Ajin
{
    
    int numero;
    string cadena;
    int nuevodato;

    
    Ajin(int numero, string cadena, int nuevodato)
    {
        this.numero = numero;
        this.cadena = cadena;
        this.nuevodato = nuevodato;
    }

    
    public void IngresodeDatos()
    {
        Console.Write("Edad (nuevodato): ");
        nuevodato = int.Parse(Console.ReadLine());
        Console.Write("Numero: ");
        numero = int.Parse(Console.ReadLine());
        Console.Write("Cadena: ");
        cadena = Console.ReadLine();
    }

    public void MostrarDatos()
    {
        show();
    }

    void show()
    {
        Console.WriteLine(numero);
        Console.WriteLine(cadena);
        Console.WriteLine(nuevodato);
        Console.ReadKey();
    }

    public static void Menu()
    {
        Ajin objetoProgram = new Ajin(0,"",0);
        bool salir = false;

        while (!salir)
        {
            Console.WriteLine("1. Ingreso de valores - llamar a método nuevo");
            Console.WriteLine("2. Mostrar valores - llamar a método");
            Console.WriteLine("3. Salir del programa");
            Console.WriteLine("");
            Console.Write("Seleccione una opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Console.WriteLine("");
                    objetoProgram.IngresodeDatos();
                    break;
                case "2":
                    Console.WriteLine("");
                    objetoProgram.MostrarDatos();
                    break;
                case "3":
                    Console.WriteLine("");
                    salir = true;
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }
    }

    public static void Main()
    {
        Menu();
    }
}
