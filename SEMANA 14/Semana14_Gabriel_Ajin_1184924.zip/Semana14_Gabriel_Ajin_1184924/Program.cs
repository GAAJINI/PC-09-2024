﻿namespace Semana14_Gabriel_Ajin
{
    class Program
    {

        static void Main(string[] args)
        {

            menu();

        }
        static void menu()
        {

            Console.Write("");
            int[] numeros = new int[12];
            int suma = 0;
            Console.WriteLine("Ingrese 12 números:");
            for (int i = 0; i < 12; i++)
            {

                Console.Write($"{i + 1}) Ingrese el número {i + 1}:", i + 1);
                numeros[i] = Convert.ToInt32(Console.ReadLine());
                suma += numeros[i];
            }
            Console.WriteLine("Los 8 números ingresados son:");
            foreach (int numero in numeros)
                Console.WriteLine(numero + " ");

            bool mostrarMenu = true;
            while (mostrarMenu)
            {

                Console.WriteLine("-------------------------------------");
                Console.WriteLine("MENU DE USUARIO");
                Console.WriteLine("1. SUMA DE LO NUMEROS");
                Console.WriteLine("2. PROMEDIO DE LOS NUMEROS");
                Console.WriteLine("3. DE MENOR A MAYOR");
                Console.WriteLine("4. DE MAYOR A MENOR");
                Console.WriteLine("5. CAMBIAR TAMAÑO DE ARREGLO");
                Console.WriteLine("6. SPLIT()");
                Console.WriteLine("7. SALIR");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("");
                Console.WriteLine("INGRESE LA OPCION QUE DESEA EFECTUAR");
                int numero = int.Parse(Console.ReadLine());


                switch (numero)
                {
                    case 1:
                        Console.WriteLine("SUMA DE LOS NUMEROS");
                        Console.WriteLine("LA SUMA ES: " + suma);
                        Console.ReadKey();
                        break;
                    case 2:
                        Console.WriteLine("PROMEDIO DE LOS NUMEROS");
                        double promedio = (double)suma / numeros.Length;
                        Console.WriteLine("El promedio de los 8 números es de: " + promedio);
                        Console.ReadKey();
                        Console.WriteLine("");
                        break;
                    case 3:
                        Console.WriteLine("DE MENOR A MAYOR");
                        Array.Sort(numeros);
                        foreach (int num in numeros)
                        {
                            Console.WriteLine(num + " ");
                        }
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.WriteLine("DE MAYOR A MENOR");
                        Array.Sort(numeros);
                        Array.Reverse(numeros);
                        foreach (int num in numeros)
                        {
                            Console.WriteLine(num + " ");
                        }
                        Console.ReadKey();
                        break;

                    case 5:
                        Console.WriteLine("CAMBIAR TAMAÑO DEL ARREGLO");

                        Array.Resize(ref numeros, 14);
                        for (int i = 12; i < numeros.Length; i++)
                        {
                            Console.Write($"{i + 1}) Ingrese el número {i + 1}: ");
                            numeros[i] = Convert.ToInt32(Console.ReadLine());
                        }

                        Console.WriteLine("LISTA DE NUMEROS TOTAL");
                        foreach (int num in numeros)
                        {
                            Console.WriteLine(num + " ");
                        }
                        Console.ReadKey();
                        break;
                    case 6:
                    
                        Console.WriteLine("SPLIT()");
                        string splitnumeros = String.Join(",", numeros);
                        string[] numarray = splitnumeros.Split(',');

                        foreach (string listasplit in numarray)
                        {
                            Console.WriteLine(listasplit);
                        }
                        Console.ReadKey();
                        break;
                    case 7:
                        Console.WriteLine("SALIR");
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("La opción seleccionada no es válida.");
                        break;
                }
            }
        }
    }
}
